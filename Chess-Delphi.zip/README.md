# Chess-Delphi
## A Chess Game in Delphi (Object Oriented Pascal with Forms)

> Projet "Chess" Réalisé par Jules Vandeputte Alias LejusVDP dans le cadre du cours de Production d'Applications de DUT
> Je suis désolé de la longueur du fichier (Vive la balise $REGION), j'ai essayé au maximum de regrouper le code répété en une méthode appelée et de combiner des tests logiques plutôt que de les découper en 6 if else
> La fonction du Pion fonctionnant en prenant en compte la Direction de celui-ci aurait été 2 fois plus longue sans la variable _direction qui évite les tests de la couleur du pion et permet un calcul global.

Bonne Lecture et bon jeu !

Jules V.